﻿Write-Host "Searching for csv file"
$Access = New-Object -com Access.Application
$Access.OpenCurrentDatabase("C:\Users\Robbe\Documents\ChristineLeDuc.accdb")
$runArgs = @([System.Reflection.Missing]::Value) * 31
$runArgs[0] = "ImportCsvFile"
$Access.GetType().GetMethod("Run").Invoke($Access, $runArgs)
Write-Host "Csv file imported correctly"
Start-Sleep -Seconds 5